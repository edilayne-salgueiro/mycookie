
# Produção: mon4d/nginx-cookie-auth + TLS + App + Postgres (slim)

## Passo 0 — gerar HTPASSWD e SCA_TOKEN

Execute o bootstrap **uma vez** com seu usuário/senha (ex.: `labredes` / `UFS#Dcomp`):

```bash
./bootstrap.sh labredes 'UFS#Dcomp' meu.dominio.br   # CN opcional; se não passar, usa localhost
```

Isso irá:
- gerar `HTPASSWD` (bcrypt) no formato esperado pelo **mon4d/nginx-cookie-auth**;
- gerar `SCA_TOKEN` aleatório;
- atualizar o `.env` com os valores.

> A imagem `mon4d/nginx-cookie-auth` requer `HTPASSWD` (usuario + hash) e `SCA_TOKEN` por **variáveis de ambiente**. Ela foi projetada para operar atrás de um proxy que **termina TLS** (como o Nginx externo), e usa **cookie seguro** (HttpOnly, Secure, SameSite=Strict) válido por 7 dias. citeturn6search10turn6search4

## Passo 1 — subir a stack

```bash
docker compose up -d
```

- `certgen` gera certificado autoassinado (`server.crt`/`server.key`) para `CERT_CN` (default: `localhost`).
- `nginx` expõe **80** (redirect) e **443** (HTTPS).
- `auth` (mon4d) protege a API e encaminha para `app:3000`.
- `db` (Postgres) **não é exposto** ao host; rede interna apenas.

## Testes

- Abra `https://<CN>:443` (aceite o aviso do certificado self‑signed).
- Acesse `https://<CN>/api/cookies` → o `mon4d` pedirá **Basic Auth** (seu usuário/senha do bootstrap). Após o login, será emitido um **cookie seguro** por 7 dias.
- Endpoints:
  - `GET /api/status`
  - `GET /api/set-cookie`
  - `POST /api/save-cookies`
  - `GET /api/cookies`

## Notas de segurança

- Em produção real, troque o cert self‑signed por Let’s Encrypt e **não** exponha `db`.
- Rotacione **SCA_TOKEN** e hashes do **HTPASSWD** periodicamente.
- Revise / ajuste CSP e headers conforme sua aplicação.

Referências:
- **Docker Hub: mon4d/nginx-cookie-auth** — visão geral, requisitos, variáveis de ambiente. citeturn6search10
- **GitHub: mon4d/nginx-cookie-auth** — código e README do projeto. citeturn6search4
