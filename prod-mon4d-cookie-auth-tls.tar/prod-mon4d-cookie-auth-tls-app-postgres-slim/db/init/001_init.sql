CREATE TABLE IF NOT EXISTS cookies_log (
    id BIGSERIAL PRIMARY KEY,
    cookie_name TEXT NOT NULL,
    cookie_value TEXT NOT NULL,
    user_agent TEXT,
    ip TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY,
    user_id TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);