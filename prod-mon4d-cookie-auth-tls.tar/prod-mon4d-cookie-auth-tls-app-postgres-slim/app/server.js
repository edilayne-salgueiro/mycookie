
import express from 'express';
import cookieParser from 'cookie-parser';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

const app = express();
app.use(express.json());
app.use(cookieParser());
app.set('trust proxy', 1);

const {
  POSTGRES_DB = 'webcookies',
  POSTGRES_USER = 'webuser',
  POSTGRES_PASSWORD = 'senha_super_secreta',
  DB_HOST = 'db',
  DB_PORT = 5432,
  APP_PORT = 3000
} = process.env;

const pool = new Pool({ host: DB_HOST, port: DB_PORT, database: POSTGRES_DB, user: POSTGRES_USER, password: POSTGRES_PASSWORD });

app.get('/api/status', (req, res) => {
  res.json({ status: 'ok', https: req.secure, chain: 'nginx TLS → mon4d/nginx-cookie-auth → app' });
});

app.get('/api/set-cookie', async (req, res) => {
  const sessionId = uuidv4();
  res.cookie('session_id', sessionId, { httpOnly: true, sameSite: 'Lax', secure: true, maxAge: 24*60*60*1000 });
  try { await pool.query('INSERT INTO sessions (id, user_id) VALUES ($1, $2)', [sessionId, 'guest']); } catch (err) { console.error('Erro ao inserir sessão:', err.message); }
  res.json({ ok: true, session_id: sessionId });
});

app.post('/api/save-cookies', async (req, res) => {
  const cookies = req.cookies || {}; const userAgent = req.headers['user-agent'] || null; const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || null;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (const [name, value] of Object.entries(cookies)) {
      await client.query('INSERT INTO cookies_log (cookie_name, cookie_value, user_agent, ip) VALUES ($1, $2, $3, $4)', [name, String(value), userAgent, ip]);
    }
    await client.query('COMMIT');
    res.json({ saved: Object.keys(cookies).length });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Erro ao salvar cookies:', err.message);
    res.status(500).json({ error: 'Falha ao salvar cookies' });
  } finally { client.release(); }
});

app.get('/api/cookies', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, cookie_name, cookie_value, user_agent, ip, created_at FROM cookies_log ORDER BY created_at DESC LIMIT 100');
    res.json(rows);
  } catch (err) { console.error('Erro ao consultar cookies:', err.message); res.status(500).json({ error: 'Falha ao consultar cookies' }); }
});

app.listen(APP_PORT, () => { console.log(`App Node escutando em http://0.0.0.0:${APP_PORT}`); });
