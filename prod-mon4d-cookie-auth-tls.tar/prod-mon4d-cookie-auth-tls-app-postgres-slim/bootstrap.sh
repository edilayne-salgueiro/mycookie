
#!/usr/bin/env bash
set -euo pipefail

USER_INPUT="$1"          # usuário (ex.: labredes)
PASS_INPUT="$2"          # senha (ex.: UFS#Dcomp)
CN_INPUT="${3:-}"         # opcional: CN do certificado

if [[ -z "$USER_INPUT" || -z "$PASS_INPUT" ]]; then
  echo "Uso: ./bootstrap.sh <usuario> <senha> [CN]"; exit 1; fi

# Gera hash bcrypt via contêiner Alpine (apache2-utils)
HASH=$(docker run --rm alpine:3.20 sh -lc "apk add --no-cache apache2-utils >/dev/null && htpasswd -nbB "$USER_INPUT" "$PASS_INPUT"")
# HASH tem formato 'usuario:$2y$...'; para o mon4d, precisamos apenas 'usuario:$2y$...'

# Gera SCA_TOKEN aleatório (hex 64)
TOKEN=$(docker run --rm alpine:3.20 sh -lc "apk add --no-cache openssl >/dev/null && openssl rand -hex 32")

# Substitui no .env
ENV_FILE=".env"
sed -i "s|^HTPASSWD=.*|HTPASSWD=${HASH}|" "$ENV_FILE"
sed -i "s|^SCA_TOKEN=.*|SCA_TOKEN=${TOKEN}|" "$ENV_FILE"

# CN opcional
if [[ -n "$CN_INPUT" ]]; then
  sed -i "s|^CERT_CN=.*|CERT_CN=${CN_INPUT}|" "$ENV_FILE"
fi

echo "HTPASSWD e SCA_TOKEN atualizados no .env." 
echo "HTPASSWD=${HASH}"
echo "SCA_TOKEN=${TOKEN}"
